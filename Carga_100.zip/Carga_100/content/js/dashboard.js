/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.866805507653941, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9935754189944134, 500, 1500, "ver_agente_catalog"], "isController": false}, {"data": [0.0029585798816568047, 500, 1500, "Transaction Controller - Quality"], "isController": true}, {"data": [0.9942563482466747, 500, 1500, "/api/v1/explicability/quality-trend"], "isController": false}, {"data": [0.9875, 500, 1500, "editar_agente_catalog"], "isController": false}, {"data": [0.9936651583710407, 500, 1500, "/api/v1/explicability/quality-matrix"], "isController": false}, {"data": [0.978125, 500, 1500, "crear_agente_catalog"], "isController": false}, {"data": [0.9947161835748792, 500, 1500, "/api/v1/explicability/experience-agents"], "isController": false}, {"data": [0.9908446544595393, 500, 1500, "/models/deployments"], "isController": false}, {"data": [0.9895114942528735, 500, 1500, "listar_agentes_registry"], "isController": false}, {"data": [0.0024110910186859553, 500, 1500, "Transaction Controller - Filtro Onwer"], "isController": true}, {"data": [0.9675324675324676, 500, 1500, "Transaction Controller - Models Admin"], "isController": true}, {"data": [0.10042865890998164, 500, 1500, "Transaction Controller - Agent Center Reader"], "isController": true}, {"data": [0.9625, 500, 1500, "agente_registrar_registry"], "isController": false}, {"data": [0.9945684972842487, 500, 1500, "/api/v1/explicability/experience-nps"], "isController": false}, {"data": [0.9862079418005456, 500, 1500, "/api/v1/explicability/risk-watchlist"], "isController": false}, {"data": [0.43661971830985913, 500, 1500, "Transaction Controller - Catalog Reader"], "isController": true}, {"data": [0.8144666155026861, 500, 1500, "listar_agentes_catalog"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller - Catalog Admin"], "isController": true}, {"data": [0.9930806257521059, 500, 1500, "/api/v1/explicability/filters"], "isController": false}, {"data": [1.0, 500, 1500, "eliminar_agente_registry"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller - Registry Admin"], "isController": true}, {"data": [1.0, 500, 1500, "Init rol flags"], "isController": false}, {"data": [0.9921426412813539, 500, 1500, "/api/v1/explicability/usage-top"], "isController": false}, {"data": [0.9941285537700866, 500, 1500, "/api/v1/explicability/metadata/overview"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller - Agent Center Admin"], "isController": true}, {"data": [0.9456454601605929, 500, 1500, "Transaction Controller - Models Reader"], "isController": true}, {"data": [0.991577765300393, 500, 1500, "traer_agente_registry"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller - Agents Explicability Admin"], "isController": true}, {"data": [0.9873417721518988, 500, 1500, "registrar_registry"], "isController": false}, {"data": [0.003094059405940594, 500, 1500, "Transaction Controller - Agents Explicability Reader"], "isController": true}, {"data": [0.994430693069307, 500, 1500, "/api/v1/explicability/metadata/overview/filtros"], "isController": false}, {"data": [0.9849468713105076, 500, 1500, "/models/catalog"], "isController": false}, {"data": [0.9924607961399277, 500, 1500, "/api/v1/explicability/cost-agents"], "isController": false}, {"data": [0.9939430648092066, 500, 1500, "/api/v1/explicability/cost-daily"], "isController": false}, {"data": [0.8273116962645438, 500, 1500, "login_reader"], "isController": false}, {"data": [0.99375, 500, 1500, "eliminar_agente_catalog"], "isController": false}, {"data": [0.9895549500454133, 500, 1500, "/api/v1/explicability/usage-identities"], "isController": false}, {"data": [0.9901295496607033, 500, 1500, "/api/v1/explicability/metadata/filters"], "isController": false}, {"data": [0.9874962338053631, 500, 1500, "api/v1/explicability/summary-cards"], "isController": false}, {"data": [0.8519088669950738, 500, 1500, "Transaction Controller - MetaData"], "isController": true}, {"data": [0.9938195302843016, 500, 1500, "Transaction Controller - Filtros"], "isController": true}, {"data": [0.8375, 500, 1500, "login_admin"], "isController": false}, {"data": [0.7757985257985258, 500, 1500, "Transaction Controller - Registry Reader"], "isController": true}, {"data": [0.9935897435897436, 500, 1500, "editar_agente_registry"], "isController": false}, {"data": [0.9948391013964785, 500, 1500, "/api/v1/explicability/value-funnel"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 60500, 0, 0.0, -1.4820819383831394E8, -1793322353387, 67867, 143.0, 416.0, 528.0, 2032.0, 33.60717160377311, 181.63338463779385, 65.59261707724816], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["ver_agente_catalog", 1790, 0, 0.0, 172.28379888268148, 129, 2510, 143.0, 223.0, 275.0, 499.0899999999999, 0.9984688285283184, 1.76092781251656, 1.9703155984258778], "isController": false}, {"data": ["Transaction Controller - Quality", 1690, 0, 0.0, 4425.586390532546, 0, 55420, 3485.0, 4469.1, 5310.749999999997, 38721.82999999995, 0.9469145154711264, 18.615884892840374, 39.988312268103996], "isController": true}, {"data": ["/api/v1/explicability/quality-trend", 3308, 0, 0.0, 170.32376058041154, 129, 2029, 139.0, 224.0999999999999, 406.0, 503.72999999999956, 1.869262387253755, 2.4273108724477055, 3.8154210933094195], "isController": false}, {"data": ["editar_agente_catalog", 80, 0, 0.0, 205.18750000000003, 147, 815, 171.0, 314.8, 412.30000000000007, 815.0, 0.04546056381327755, 0.0223140780143053, 0.15385781540965365], "isController": false}, {"data": ["/api/v1/explicability/quality-matrix", 3315, 0, 0.0, 163.58914027149353, 128, 2136, 139.0, 201.0, 268.59999999999945, 509.6800000000003, 1.8672679475993355, 1.6838256600848522, 3.893411762753046], "isController": false}, {"data": ["crear_agente_catalog", 160, 0, 0.0, 246.08749999999992, 168, 922, 201.0, 371.40000000000003, 461.79999999999995, 888.4499999999992, 0.08984004541414295, 0.0449309895094902, 0.30510960345165455], "isController": false}, {"data": ["/api/v1/explicability/experience-agents", 3312, 0, 0.0, 158.77536231884048, 129, 1813, 138.0, 189.0, 227.3499999999999, 482.0, 1.8777000442211969, 1.5459480556846916, 3.8400289351195673], "isController": false}, {"data": ["/models/deployments", 1693, 0, 0.0, 180.5989367985823, 137, 2063, 151.0, 224.60000000000014, 284.0, 684.5999999999995, 0.9488649770181876, 11.826393504443356, 1.87890406725676], "isController": false}, {"data": ["listar_agentes_registry", 3480, 0, 0.0, 188.1209770114947, 134, 2608, 148.0, 248.0, 321.0, 730.8000000000011, 1.9427806438754678, 32.01899225965207, 3.8242011666662945], "isController": false}, {"data": ["Transaction Controller - Filtro Onwer", 1659, 0, 0.0, 2245.2712477396026, 0, 29287, 1932.0, 2394.0, 3013.0, 12722.60000000011, 0.9424005253357479, 8.351715776773208, 21.108140056431843], "isController": true}, {"data": ["Transaction Controller - Models Admin", 77, 0, 0.0, 369.7532467532468, 298, 677, 350.0, 441.40000000000003, 519.7999999999995, 677.0, 0.04507660974720218, 1.5335200070263897, 0.17855878278957477], "isController": true}, {"data": ["Transaction Controller - Agent Center Reader", 1633, 0, 0.0, 1842.6546233925285, 1359, 12648, 1655.0, 2288.6000000000004, 3075.999999999999, 4314.960000000008, 0.9077663777342084, 113.54175935098733, 12.376532541937639], "isController": true}, {"data": ["agente_registrar_registry", 80, 0, 0.0, 257.86249999999995, 169, 1687, 190.0, 400.70000000000005, 594.4500000000002, 1687.0, 0.04544896762670036, 0.022724483813350183, 0.15230952124625616], "isController": false}, {"data": ["/api/v1/explicability/experience-nps", 3314, 0, 0.0, 160.43964996982538, 128, 2089, 138.0, 192.0, 237.0, 506.4999999999991, 1.875120589944397, 1.3776588889217376, 3.829238534088832], "isController": false}, {"data": ["/api/v1/explicability/risk-watchlist", 3299, 0, 0.0, 198.7065777508339, 129, 2642, 141.0, 413.0, 440.0, 660.0, 1.8711307607884953, 2.3486197822874986, 4.022066295151168], "isController": false}, {"data": ["Transaction Controller - Catalog Reader", 1633, 0, 0.0, 1254.48867115738, 928, 5567, 1128.0, 1577.6000000000001, 2026.7999999999997, 3264.7400000000034, 0.9077663777342084, 82.41232587305112, 7.067719235412506], "isController": true}, {"data": ["listar_agentes_catalog", 5212, 0, 0.0, 361.20414428242503, 137, 3812, 245.0, 643.0, 764.3499999999995, 1472.7099999999964, 2.8979318596804937, 86.05749151370097, 5.625117696337386], "isController": false}, {"data": ["Transaction Controller - Catalog Admin", 80, 0, 0.0, 2559.0875, 1906, 5011, 2440.5, 3064.4, 3645.1000000000004, 5011.0, 0.04541452390535386, 4.238001101373165, 0.9971171179545752], "isController": true}, {"data": ["/api/v1/explicability/filters", 1662, 0, 0.0, 163.09987966305653, 129, 2471, 138.0, 195.70000000000005, 240.8499999999999, 530.8299999999936, 0.9442763332079601, 1.054308965639591, 1.9159251660295737], "isController": false}, {"data": ["eliminar_agente_registry", 77, 0, 0.0, 193.48051948051946, 148, 497, 163.0, 294.8, 389.19999999999993, 497.0, 0.045082020002365344, 0.02517853230068185, 0.0938907623867241], "isController": false}, {"data": ["Transaction Controller - Registry Admin", 80, 0, 0.0, 2710.224999999999, 1665, 20360, 2042.5, 2600.7000000000003, 3934.7500000000005, 20360.0, 0.04504418271271834, 3.753486877221945, 1.0749157471436357], "isController": true}, {"data": ["Init rol flags", 2682, 0, 0.0, 0.39522744220730766, 0, 45, 0.0, 1.0, 1.0, 3.0, 1.490677430076557, 0.0, 0.0], "isController": false}, {"data": ["/api/v1/explicability/usage-top", 3309, 0, 0.0, 166.29193109700844, 128, 2084, 138.0, 205.0, 306.0, 573.3000000000006, 1.8582214647322595, 1.6070660648903403, 3.7855456937374177], "isController": false}, {"data": ["/api/v1/explicability/metadata/overview", 1618, 0, 0.0, 174.16131025957978, 131, 2390, 144.0, 237.10000000000014, 320.1999999999998, 509.09999999999945, 0.9372288379173362, 2.177818558789098, 1.8741680501122011], "isController": false}, {"data": ["Transaction Controller - Agent Center Admin", 77, 0, 0.0, 4706.727272727273, 3726, 7942, 4522.0, 5512.6, 6010.299999999994, 7942.0, 0.045043964664472184, 7.970968515804289, 2.0788114177383132], "isController": true}, {"data": ["Transaction Controller - Models Reader", 1619, 0, 0.0, 405.78752316244606, 0, 3007, 348.0, 492.0, 621.0, 1836.9999999999952, 0.9054668047703951, 30.759327629377168, 3.5831368543655358], "isController": true}, {"data": ["traer_agente_registry", 1781, 0, 0.0, 177.746209994385, 135, 2172, 148.0, 221.0, 272.89999999999986, 529.6800000000017, 0.9952511821751129, 1.549821426875023, 1.9415524895110248], "isController": false}, {"data": ["Transaction Controller - Agents Explicability Admin", 74, 0, 0.0, 4527.756756756757, 3603, 7467, 4395.0, 5389.0, 6036.25, 7467.0, 0.04452512450488362, 1.1604319442873363, 2.191539132018799], "isController": true}, {"data": ["registrar_registry", 79, 0, 0.0, 222.37974683544303, 168, 623, 190.0, 309.0, 414.0, 623.0, 0.04487012371090691, 0.02243117920531035, 0.15663553606592387], "isController": false}, {"data": ["Transaction Controller - Agents Explicability Reader", 1616, 0, 0.0, -5.548640644236383E9, -1793322353387, 67867, 3970.5, 5121.099999999999, 6070.45, 47783.08999999986, 0.9054519863913255, 22.973994165094545, 43.43674483654939], "isController": true}, {"data": ["/api/v1/explicability/metadata/overview/filtros", 1616, 0, 0.0, 163.49319306930673, 129, 2113, 139.0, 202.0, 257.4499999999996, 491.9599999999991, 0.9360622017967065, 0.9676475356902676, 1.923939805292111], "isController": false}, {"data": ["/models/catalog", 1694, 0, 0.0, 223.33943329397832, 153, 2710, 178.0, 288.0, 353.25, 1026.6999999999957, 0.9481394582172179, 20.438737637876212, 1.880245349625026], "isController": false}, {"data": ["/api/v1/explicability/cost-agents", 1658, 0, 0.0, 162.24185765983117, 129, 2112, 138.0, 194.0, 240.14999999999986, 562.9900000000032, 0.9434552769194876, 0.7842713161215339, 1.929922492488776], "isController": false}, {"data": ["/api/v1/explicability/cost-daily", 1651, 0, 0.0, 159.31374924288303, 128, 1842, 138.0, 192.0, 243.79999999999973, 528.2000000000003, 0.941012588821956, 0.7626101333120167, 1.9240066788525232], "isController": false}, {"data": ["login_reader", 1633, 0, 0.0, 512.8407838334344, 413, 14037, 484.0, 555.6000000000001, 594.3, 719.5800000000011, 0.9084531762760764, 2.451876980808996, 0.4178529746347968], "isController": false}, {"data": ["eliminar_agente_catalog", 80, 0, 0.0, 204.22499999999997, 147, 1107, 164.5, 284.8, 335.6, 1107.0, 0.04543954524103123, 0.02479317374491716, 0.09463539663895044], "isController": false}, {"data": ["/api/v1/explicability/usage-identities", 3303, 0, 0.0, 187.95458673932777, 129, 2808, 140.0, 406.5999999999999, 430.0, 584.7200000000003, 1.8573553351871275, 1.9894130034203341, 3.814644496291475], "isController": false}, {"data": ["/api/v1/explicability/metadata/filters", 1621, 0, 0.0, 171.92288710672426, 130, 2437, 142.0, 214.0, 296.0, 607.7999999999997, 0.9373355615050567, 2.472858500313698, 1.8734666336223598], "isController": false}, {"data": ["api/v1/explicability/summary-cards", 3319, 0, 0.0, 200.95450436878622, 128, 2741, 140.0, 417.0, 441.0, 602.4000000000005, 1.8617649352084487, 1.4112045379678884, 3.800023889097372], "isController": false}, {"data": ["Transaction Controller - MetaData", 1624, 0, 0.0, 522.7592364532021, 0, 9516, 448.0, 667.5, 806.5, 1620.5, 0.9380619201734721, 5.606842040574932, 5.65891058732698], "isController": true}, {"data": ["Transaction Controller - Filtros", 1618, 0, 0.0, 164.82880098887495, 0, 2639, 139.0, 202.10000000000014, 260.2499999999998, 506.9599999999991, 0.9360923179103735, 0.9664825262646792, 1.921623457732944], "isController": true}, {"data": ["login_admin", 80, 0, 0.0, 493.45, 423, 804, 478.0, 569.8, 576.9, 804.0, 0.045460408814091365, 0.12276974075633619, 0.020954407187745237], "isController": false}, {"data": ["Transaction Controller - Registry Reader", 1628, 0, 0.0, 557.5663390663377, 0, 5116, 484.0, 695.3000000000004, 833.6499999999999, 2283.880000000001, 0.9083756925806686, 31.245998851452953, 5.328692364280692], "isController": true}, {"data": ["editar_agente_registry", 78, 0, 0.0, 194.58974358974353, 149, 542, 174.0, 243.50000000000028, 344.34999999999997, 542.0, 0.04444381134171878, 0.021829060483468894, 0.15458291192433155], "isController": false}, {"data": ["/api/v1/explicability/value-funnel", 3294, 0, 0.0, 162.16150576806356, 128, 2446, 139.0, 196.0, 255.25, 494.0500000000002, 1.859484187892579, 1.8024365129605031, 3.7935896210764684], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 60500, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
