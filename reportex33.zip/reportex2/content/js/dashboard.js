/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9999983620368307, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-2 | 116"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-9 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-4 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-1 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-2 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-5 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-2 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-2 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-5 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-9 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-9 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-6 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-7 | 9"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-3 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-6 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-3 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-6 | 9"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-1 | 174"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-4 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-7 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-3 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-2 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-3 | 198"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-1 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-3 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-1 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-1 | 198"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-1 | 9"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-6 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-6 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-3 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-3 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-7 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-3 | 116"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-6 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-2 | 174"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-4 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-7 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-4 | 198"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-3 | 9"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-6 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-7 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-4 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-4 | 116"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-8 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-4 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-2 | 9"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-8 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-1 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-4 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-5 | 9"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-1 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-1 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-10 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-5 | 198"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-1 | 116"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-7 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-5 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-5 | 197"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-5 | 116"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-5 | 117"], "isController": false}, {"data": [0.999999953860119, 500, 1500, "INIT - Cargar CSV + Selección random sin repetir"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-2 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-8 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-5 | 83"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-2 | 198"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-8 | 117"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-4 | 9"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-8 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-2 | 197"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 43346518, 0, 0.0, 0.24625691964460814, 0, 161646, 0.0, 1.0, 1.0, 1.0, 24081.69322069492, 4977.620765430015, 0.01324885984717591], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["POST Dispatcher | VU-8 | Q-2 | 116", 1, 0, 0.0, 31948.0, 31948, 31948, 31948.0, 31948.0, 31948.0, 31948.0, 0.03130086390384375, 0.03151483465318643, 0.011248747965443846], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-9 | 117", 1, 0, 0.0, 37152.0, 37152, 37152, 37152.0, 37152.0, 37152.0, 37152.0, 0.026916451335055987, 0.01377365283161068, 0.009725670892549526], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-4 | 2", 1, 0, 0.0, 49631.0, 49631, 49631, 49631.0, 49631.0, 49631.0, 49631.0, 0.02014869738671395, 0.0085789375591868, 0.007693496756059721], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-1 | 1", 1, 0, 0.0, 22763.0, 22763, 22763, 22763.0, 22763.0, 22763.0, 22763.0, 0.04393094056143742, 0.031532462219391114, 0.013642616307165135], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-2 | 1", 1, 0, 0.0, 26231.0, 26231, 26231, 26231.0, 26231.0, 26231.0, 26231.0, 0.038122831763943425, 0.02754970264191224, 0.011838926270443367], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-5 | 197", 1, 0, 0.0, 41869.0, 41869, 41869, 41869.0, 41869.0, 41869.0, 41869.0, 0.02388401920275144, 0.017493178127015216, 0.007510404475865199], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-2 | 197", 1, 0, 0.0, 20849.0, 20849, 20849, 20849.0, 20849.0, 20849.0, 20849.0, 0.047963931123794906, 0.01653444110029258, 0.01508240802916207], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-2 | 117", 1, 0, 0.0, 35507.0, 35507, 35507, 35507.0, 35507.0, 35507.0, 35507.0, 0.028163460726054017, 0.013394145872644831, 0.010176250457656237], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-5 | 2", 1, 0, 0.0, 25533.0, 25533, 25533, 25533.0, 25533.0, 25533.0, 25533.0, 0.03916500215407512, 0.01690520600791133, 0.014954605314690792], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-9 | 197", 1, 0, 0.0, 56876.0, 56876, 56876, 56876.0, 56876.0, 56876.0, 56876.0, 0.017582108446444897, 0.0061125298895843595, 0.005528748945073493], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-9 | 83", 1, 0, 0.0, 32271.0, 32271, 32271, 32271.0, 32271.0, 32271.0, 32271.0, 0.030987573982832882, 0.03077574486380961, 0.010863807675622075], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-6 | 197", 1, 0, 0.0, 24870.0, 24870, 24870, 24870.0, 24870.0, 24870.0, 24870.0, 0.04020908725371934, 0.027643747486932047, 0.012643873140329715], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-7 | 9", 1, 0, 0.0, 161646.0, 161646, 161646, 161646.0, 161646.0, 161646.0, 161646.0, 0.00618635784368311, 0.002301760096136001, 0.0022715532707273923], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-3 | 1", 1, 0, 0.0, 21981.0, 21981, 21981, 21981.0, 21981.0, 21981.0, 21981.0, 0.0454938355852782, 0.01506094752286065, 0.014127968472771939], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-6 | 2", 1, 0, 0.0, 41753.0, 41753, 41753, 41753.0, 41753.0, 41753.0, 41753.0, 0.023950374823365986, 0.009542727468684885, 0.009145113824156347], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-3 | 83", 1, 0, 0.0, 31494.0, 31494, 31494, 31494.0, 31494.0, 31494.0, 31494.0, 0.031752079761224364, 0.028682298612434116, 0.011131832650663618], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-6 | 9", 1, 0, 0.0, 23820.0, 23820, 23820, 23820.0, 23820.0, 23820.0, 23820.0, 0.041981528127623846, 0.017546966834592777, 0.01541509235936188], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-1 | 174", 1, 0, 0.0, 55611.0, 55611, 55611, 55611.0, 55611.0, 55611.0, 55611.0, 0.017982053910197623, 0.01273143465321609, 0.006655467218715722], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-4 | 83", 1, 0, 0.0, 27301.0, 27301, 27301, 27301.0, 27301.0, 27301.0, 27301.0, 0.03662869491960002, 0.020353249423098057, 0.012841505347789458], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-7 | 83", 1, 0, 0.0, 27881.0, 27881, 27881, 27881.0, 27881.0, 27881.0, 27881.0, 0.035866719271188265, 0.017513046519134896, 0.012574367400738855], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-3 | 117", 1, 0, 0.0, 32547.0, 32547, 32547, 32547.0, 32547.0, 32547.0, 32547.0, 0.030724797984453253, 0.02898452622361508, 0.011101733646726274], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-2 | 2", 1, 0, 0.0, 27843.0, 27843, 27843, 27843.0, 27843.0, 27843.0, 27843.0, 0.035915670006823976, 0.028094191089322273, 0.013713893527996264], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-3 | 198", 1, 0, 0.0, 26058.0, 26058, 26058, 26058.0, 26058.0, 26058.0, 26058.0, 0.038375930616317444, 0.024172339108910892, 0.0135290146020416], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-1 | 83", 1, 0, 0.0, 23901.0, 23901, 23901, 23901.0, 23901.0, 23901.0, 23901.0, 0.041839253587715994, 0.0241066011882348, 0.014668253943349651], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-3 | 197", 1, 0, 0.0, 25349.0, 25349, 25349, 25349.0, 25349.0, 25349.0, 25349.0, 0.03944928794035268, 0.013291019862716478, 0.012404951871868714], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-1 | 197", 1, 0, 0.0, 24833.0, 24833, 24833, 24833.0, 24833.0, 24833.0, 24833.0, 0.040268996899287236, 0.014668296722103654, 0.012662711915596184], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-1 | 198", 1, 0, 0.0, 25507.0, 25507, 25507, 25507.0, 25507.0, 25507.0, 25507.0, 0.03920492413847179, 0.028178539224526598, 0.013821267201160465], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-1 | 9", 1, 0, 0.0, 30888.0, 30888, 30888, 30888.0, 30888.0, 30888.0, 30888.0, 0.03237503237503238, 0.013310438115125615, 0.011887707200207199], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-6 | 117", 1, 0, 0.0, 29931.0, 29931, 29931, 29931.0, 29931.0, 29931.0, 29931.0, 0.03341017673983495, 0.020424580702281914, 0.012072036517323177], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-6 | 197", 1, 0, 0.0, 29277.0, 29277, 29277, 29277.0, 29277.0, 29277.0, 29277.0, 0.03415650510639751, 0.025417243057690338, 0.010740619769785156], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-3 | 2", 1, 0, 0.0, 31970.0, 31970, 31970, 31970.0, 31970.0, 31970.0, 31970.0, 0.03127932436659368, 0.01282941038473569, 0.011943570143884892], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-3 | 197", 1, 0, 0.0, 23721.0, 23721, 23721, 23721.0, 23721.0, 23721.0, 23721.0, 0.042156738754689935, 0.015973451793769234, 0.013256318241220859], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-7 | 197", 1, 0, 0.0, 51088.0, 51088, 51088, 51088.0, 51088.0, 51088.0, 51088.0, 0.019574068274350143, 0.0068432777756028814, 0.006155126937832759], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-3 | 116", 1, 0, 0.0, 34694.0, 34694, 34694, 34694.0, 34694.0, 34694.0, 34694.0, 0.028823427682019946, 0.023559774384619817, 0.010358419323225917], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-6 | 1", 1, 0, 0.0, 20845.0, 20845, 20845, 20845.0, 20845.0, 20845.0, 20845.0, 0.04797313504437515, 0.015881731230510916, 0.01489790717198369], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-2 | 174", 1, 0, 0.0, 37959.0, 37959, 37959, 37959.0, 37959.0, 37959.0, 37959.0, 0.02634421349350615, 0.017751471982928948, 0.009750446205116045], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-4 | 197", 1, 0, 0.0, 19055.0, 19055, 19055, 19055.0, 19055.0, 19055.0, 19055.0, 0.05247966413014957, 0.0189111289687746, 0.016502394384675937], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-7 | 1", 1, 0, 0.0, 33205.0, 33205, 33205, 33205.0, 33205.0, 33205.0, 33205.0, 0.03011594639361542, 0.015587355067007981, 0.00935241304020479], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-4 | 198", 1, 0, 0.0, 25041.0, 25041, 25041, 25041.0, 25041.0, 25041.0, 25041.0, 0.03993450740785112, 0.02632401611357374, 0.01407847380296314], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-3 | 9", 1, 0, 0.0, 23360.0, 23360, 23360, 23360.0, 23360.0, 23360.0, 23360.0, 0.04280821917808219, 0.01801791256421233, 0.015718642979452056], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-6 | 83", 1, 0, 0.0, 28309.0, 28309, 28309, 28309.0, 28309.0, 28309.0, 28309.0, 0.03532445512027977, 0.019421551008513192, 0.012384257215019958], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-7 | 117", 1, 0, 0.0, 29868.0, 29868, 29868, 29868.0, 29868.0, 29868.0, 29868.0, 0.03348064818534887, 0.019944526751037903, 0.01209749983259676], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-4 | 117", 1, 0, 0.0, 25733.0, 25733, 25733, 25733.0, 25733.0, 25733.0, 25733.0, 0.03886060700268138, 0.018785156705397738, 0.014041430264640734], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-4 | 116", 1, 0, 0.0, 90819.0, 90819, 90819, 90819.0, 90819.0, 90819.0, 90819.0, 0.011010911813607286, 0.009268951155595194, 0.003957046433015118], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-8 | 1", 1, 0, 0.0, 20490.0, 20490, 20490, 20490.0, 20490.0, 20490.0, 20490.0, 0.04880429477794045, 0.01615689055636896, 0.015156021229868229], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-4 | 197", 1, 0, 0.0, 28446.0, 28446, 28446, 28446.0, 28446.0, 28446.0, 28446.0, 0.03515432749771497, 0.012564925648597342, 0.011054388138929902], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-2 | 9", 1, 0, 0.0, 39922.0, 39922, 39922, 39922.0, 39922.0, 39922.0, 39922.0, 0.02504884524823406, 0.011790569735985171, 0.009197622864585944], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-8 | 197", 1, 0, 0.0, 33268.0, 33268, 33268, 33268.0, 33268.0, 33268.0, 33268.0, 0.03005891547432969, 0.019667454460743056, 0.009452119905013826], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-1 | 197", 1, 0, 0.0, 24083.0, 24083, 24083, 24083.0, 24083.0, 24083.0, 24083.0, 0.041523066063198104, 0.014233004090022008, 0.013057057883154094], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-4 | 1", 1, 0, 0.0, 32919.0, 32919, 32919, 32919.0, 32919.0, 32919.0, 32919.0, 0.03037759348704396, 0.020261617530909205, 0.009433666727421854], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-5 | 9", 1, 0, 0.0, 38698.0, 38698, 38698, 38698.0, 38698.0, 38698.0, 38698.0, 0.025841128740503386, 0.009816600664117008, 0.009488539459403587], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-1 | 2", 1, 0, 0.0, 38148.0, 38148, 38148, 38148.0, 38148.0, 38148.0, 38148.0, 0.026213694033763238, 0.01052131664831708, 0.010009330436720141], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-1 | 117", 1, 0, 0.0, 31133.0, 31133, 31133, 31133.0, 31133.0, 31133.0, 31133.0, 0.03212025824687631, 0.030896928098801915, 0.011605952686859603], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-10 | 197", 1, 0, 0.0, 124507.0, 124507, 124507, 124507.0, 124507.0, 124507.0, 124507.0, 0.008031676933827014, 0.002902070767105464, 0.0025255859108323227], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-5 | 198", 1, 0, 0.0, 30175.0, 30175, 30175, 30175.0, 30175.0, 30175.0, 30175.0, 0.033140016570008285, 0.04100429784589892, 0.011683150372825185], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-1 | 116", 1, 0, 0.0, 32254.0, 32254, 32254, 32254.0, 32254.0, 32254.0, 32254.0, 0.03100390649221802, 0.021981285266943637, 0.011142028895640851], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-7 | 2", 1, 0, 0.0, 26435.0, 26435, 26435, 26435.0, 26435.0, 26435.0, 26435.0, 0.03782863627766219, 0.017104158785700777, 0.014444332797427654], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-5 | 1", 1, 0, 0.0, 25825.0, 25825, 25825, 25825.0, 25825.0, 25825.0, 25825.0, 0.03872216844143272, 0.012819155372700872, 0.012025048402710552], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-5 | 197", 1, 0, 0.0, 23666.0, 23666, 23666, 23666.0, 23666.0, 23666.0, 23666.0, 0.04225471140032114, 0.03119586115101834, 0.013287126045804107], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-5 | 116", 1, 0, 0.0, 26753.0, 26753, 26753, 26753.0, 26753.0, 26753.0, 26753.0, 0.037378985534332596, 0.03580936016521512, 0.013433072926400778], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-5 | 117", 1, 0, 0.0, 36241.0, 36241, 36241, 36241.0, 36241.0, 36241.0, 36241.0, 0.02759305758671118, 0.025599028034546507, 0.009970147760823377], "isController": false}, {"data": ["INIT - Cargar CSV + Selección random sin repetir", 43346449, 0, 0.0, 0.1890222426294075, 0, 1642, 0.0, 1.0, 1.0, 1.0, 24081.654886893062, 4977.598343823508, 0.0], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-2 | 83", 1, 0, 0.0, 75316.0, 75316, 75316, 75316.0, 75316.0, 75316.0, 75316.0, 0.013277391258165596, 0.008116842702745763, 0.0046548666617982895], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-8 | 83", 1, 0, 0.0, 35364.0, 35364, 35364, 35364.0, 35364.0, 35364.0, 35364.0, 0.028277344191833503, 0.03145302249462731, 0.009913639223504129], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-5 | 83", 1, 0, 0.0, 33286.0, 33286, 33286, 33286.0, 33286.0, 33286.0, 33286.0, 0.03004266057802079, 0.016312225860722226, 0.01053253432373971], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-2 | 198", 1, 0, 0.0, 31000.0, 31000, 31000, 31000.0, 31000.0, 31000.0, 31000.0, 0.03225806451612903, 0.017326108870967742, 0.011372227822580645], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-8 | 117", 1, 0, 0.0, 36200.0, 36200, 36200, 36200.0, 36200.0, 36200.0, 36200.0, 0.027624309392265192, 0.01499913674033149, 0.00998143991712707], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-4 | 9", 1, 0, 0.0, 53677.0, 53677, 53677, 53677.0, 53677.0, 53677.0, 53677.0, 0.01862995323881737, 0.007550225189559774, 0.006840685954878254], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-8 | 2", 1, 0, 0.0, 27685.0, 27685, 27685, 27685.0, 27685.0, 27685.0, 27685.0, 0.036120642947444465, 0.017531210493046775, 0.01379215956294022], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-2 | 197", 1, 0, 0.0, 26658.0, 26658, 26658, 26658.0, 26658.0, 26658.0, 26658.0, 0.037512191462225224, 0.02850047359141721, 0.01179582583089504], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 43346518, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
