/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9999980293090327, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-10 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-2 | 178"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-6 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-3 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-1 | 182"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-5 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-8 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-2 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-7 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-6 | 91"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-1 | 91"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-2 | 58"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-4 | 91"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-4 | 182"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-7 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-3 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-1 | 65"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-2 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-3 | 58"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-8 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-1 | 178"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-2 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-2 | 182"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-5 | 91"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-6 | 58"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-7 | 58"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-2 | 91"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-4 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-4 | 58"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-1 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-4 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-9 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-3 | 178"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-1 | 88"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-6 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-5 | 58"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-5 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-3 | 182"], "isController": false}, {"data": [1.0, 500, 1500, "INIT - Cargar CSV + Selección random sin repetir"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-1 | 102"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-3 | 91"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-1 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-1 | 103"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-1 | 58"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 21819758, 0, 0.0, 0.4852970871629372, 0, 28504, 1.0, 1.0, 2.0, 2.0, 12122.121450337361, 2505.1360309768224, 0.008675154305984183], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["POST Dispatcher | VU-3 | Q-10 | 102", 1, 0, 0.0, 12022.0, 12022, 12022, 12022.0, 12022.0, 12022.0, 12022.0, 0.08318083513558476, 0.06734073469472633, 0.03021803776409915], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-2 | 178", 1, 0, 0.0, 8802.0, 8802, 8802, 8802.0, 8802.0, 8802.0, 8802.0, 0.11361054305839582, 0.07888388292433539, 0.04182731907521018], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-6 | 2", 1, 0, 0.0, 12229.0, 12229, 12229, 12229.0, 12229.0, 12229.0, 12229.0, 0.08177283506419168, 0.03936914813149072, 0.03146337599149563], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-3 | 102", 1, 0, 0.0, 13805.0, 13805, 13805, 13805.0, 13805.0, 13805.0, 13805.0, 0.07243752263672582, 0.06628316280333213, 0.026315193770373054], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-1 | 182", 1, 0, 0.0, 14735.0, 14735, 14735, 14735.0, 14735.0, 14735.0, 14735.0, 0.0678656260604004, 0.03247476247030879, 0.024322934340006788], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-5 | 102", 1, 0, 0.0, 16983.0, 16983, 16983, 16983.0, 16983.0, 16983.0, 16983.0, 0.0588824118235883, 0.07987077150680091, 0.021390876170287933], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-8 | 102", 1, 0, 0.0, 12889.0, 12889, 12889, 12889.0, 12889.0, 12889.0, 12889.0, 0.07758553805570642, 0.06985729110093879, 0.0281853712467996], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-2 | 2", 1, 0, 0.0, 13678.0, 13678, 13678, 13678.0, 13678.0, 13678.0, 13678.0, 0.07311010381634742, 0.03669784507969001, 0.028130254788711798], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-7 | 2", 1, 0, 0.0, 12125.0, 12125, 12125, 12125.0, 12125.0, 12125.0, 12125.0, 0.08247422680412371, 0.04059278350515464, 0.03173324742268041], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-6 | 91", 1, 0, 0.0, 14610.0, 14610, 14610, 14610.0, 14610.0, 14610.0, 14610.0, 0.06844626967830253, 0.05013154517453799, 0.02493208846680356], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-1 | 91", 1, 0, 0.0, 16658.0, 16658, 16658, 16658.0, 16658.0, 16658.0, 16658.0, 0.06003121623244087, 0.03734363744146956, 0.0218668395065434], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-2 | 58", 1, 0, 0.0, 13363.0, 13363, 13363, 13363.0, 13363.0, 13363.0, 13363.0, 0.07483349547257352, 0.07154491412856395, 0.0264548099229215], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-4 | 91", 1, 0, 0.0, 12230.0, 12230, 12230, 12230.0, 12230.0, 12230.0, 12230.0, 0.08176614881439084, 0.05062474448078495, 0.029783958503679476], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-4 | 182", 1, 0, 0.0, 28504.0, 28504, 28504, 28504.0, 28504.0, 28504.0, 28504.0, 0.03508279539713725, 0.025421322445972495, 0.012573619053466179], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-7 | 102", 1, 0, 0.0, 13166.0, 13166, 13166, 13166.0, 13166.0, 13166.0, 13166.0, 0.07595321282090232, 0.09716670780799028, 0.02759237809509342], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-3 | 2", 1, 0, 0.0, 12673.0, 12673, 12673, 12673.0, 12673.0, 12673.0, 12673.0, 0.07890791446382071, 0.03614044129251164, 0.03036105302611852], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-1 | 65", 1, 0, 0.0, 12566.0, 12566, 12566, 12566.0, 12566.0, 12566.0, 12566.0, 0.07957981855801369, 0.04546307993792774, 0.028054994628362247], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-2 | 102", 1, 0, 0.0, 17441.0, 17441, 17441, 17441.0, 17441.0, 17441.0, 17441.0, 0.05733616191732126, 0.04249819032738949, 0.020829152571526864], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-3 | 58", 1, 0, 0.0, 17024.0, 17024, 17024, 17024.0, 17024.0, 17024.0, 17024.0, 0.0587406015037594, 0.08862717707354323, 0.02076572045347744], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-8 | 2", 1, 0, 0.0, 12881.0, 12881, 12881, 12881.0, 12881.0, 12881.0, 12881.0, 0.07763372408974459, 0.0369973216365189, 0.02987078837046813], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-1 | 178", 1, 0, 0.0, 11945.0, 11945, 11945, 11945.0, 11945.0, 11945.0, 11945.0, 0.08371703641691083, 0.045128714943491, 0.03082160422771034], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-2 | 1", 1, 0, 0.0, 6345.0, 6345, 6345, 6345.0, 6345.0, 6345.0, 6345.0, 0.15760441292356187, 0.05202176910953507, 0.04940528959810875], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-2 | 182", 1, 0, 0.0, 17933.0, 17933, 17933, 17933.0, 17933.0, 17933.0, 17933.0, 0.05576311827357386, 0.03801040679194781, 0.019985414459376568], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-5 | 91", 1, 0, 0.0, 12592.0, 12592, 12592, 12592.0, 12592.0, 12592.0, 12592.0, 0.07941550190597205, 0.06343933648348157, 0.028927717002858958], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-6 | 58", 1, 0, 0.0, 13364.0, 13364, 13364, 13364.0, 13364.0, 13364.0, 13364.0, 0.074827895839569, 0.07395100643519904, 0.02645283036516013], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-7 | 58", 1, 0, 0.0, 18270.0, 18270, 18270, 18270.0, 18270.0, 18270.0, 18270.0, 0.05473453749315819, 0.06232467843459223, 0.019349514230979747], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-2 | 91", 1, 0, 0.0, 14520.0, 14520, 14520, 14520.0, 14520.0, 14520.0, 14520.0, 0.06887052341597795, 0.04607061380853995, 0.02508662620523416], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-4 | 2", 1, 0, 0.0, 13365.0, 13365, 13365, 13365.0, 13365.0, 13365.0, 13365.0, 0.07482229704451927, 0.035949775533108866, 0.028789047886270108], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-4 | 58", 1, 0, 0.0, 14000.0, 14000, 14000, 14000.0, 14000.0, 14000.0, 14000.0, 0.07142857142857144, 0.06724330357142858, 0.025251116071428572], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-1 | 1", 1, 0, 0.0, 8533.0, 8533, 8533, 8533.0, 8533.0, 8533.0, 8533.0, 0.11719207781553967, 0.038568095921715694, 0.03673696970584789], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-4 | 102", 1, 0, 0.0, 13854.0, 13854, 13854, 13854.0, 13854.0, 13854.0, 13854.0, 0.07218131947451999, 0.09600679406669554, 0.02622211996535297], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-9 | 102", 1, 0, 0.0, 17079.0, 17079, 17079, 17079.0, 17079.0, 17079.0, 17079.0, 0.0585514374377891, 0.061753469172668184, 0.02127063938169682], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-3 | 178", 1, 0, 0.0, 13538.0, 13538, 13538, 13538.0, 13538.0, 13538.0, 13538.0, 0.07386615452799528, 0.0383036406780913, 0.02719486353227951], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-1 | 88", 1, 0, 0.0, 15464.0, 15464, 15464, 15464.0, 15464.0, 15464.0, 15464.0, 0.06466632177961718, 0.04711042582772892, 0.022607952340920848], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-6 | 102", 1, 0, 0.0, 14661.0, 14661, 14661, 14661.0, 14661.0, 14661.0, 14661.0, 0.0682081713389264, 0.08339514698860924, 0.02477874974421936], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-5 | 58", 1, 0, 0.0, 12465.0, 12465, 12465, 12465.0, 12465.0, 12465.0, 12465.0, 0.08022462896109105, 0.06784621941436021, 0.028360659847573206], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-5 | 2", 1, 0, 0.0, 14563.0, 14563, 14563, 14563.0, 14563.0, 14563.0, 14563.0, 0.06866717022591498, 0.031181869292041475, 0.02642076666895557], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-3 | 182", 1, 0, 0.0, 14726.0, 14726, 14726, 14726.0, 14726.0, 14726.0, 14726.0, 0.06790710308298248, 0.03123461479695776, 0.02433779964009235], "isController": false}, {"data": ["INIT - Cargar CSV + Selección random sin repetir", 21819715, 0, 0.0, 0.4574669742478533, 0, 193, 1.0, 1.0, 2.0, 2.0, 12122.097561382114, 2505.116481226337, 0.0], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-1 | 102", 1, 0, 0.0, 14376.0, 14376, 14376, 14376.0, 14376.0, 14376.0, 14376.0, 0.06956037840845855, 0.08036125747774069, 0.02526998121869783], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-3 | 91", 1, 0, 0.0, 14546.0, 14546, 14546, 14546.0, 14546.0, 14546.0, 14546.0, 0.06874742197167606, 0.049747890313488245, 0.02504178554241716], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-1 | 2", 1, 0, 0.0, 15323.0, 15323, 15323, 15323.0, 15323.0, 15323.0, 15323.0, 0.0652613717940351, 0.04454853406643607, 0.02511033250668929], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-1 | 103", 1, 0, 0.0, 12909.0, 12909, 12909, 12909.0, 12909.0, 12909.0, 12909.0, 0.07746533426291735, 0.20796113661011695, 0.02920079982957626], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-1 | 58", 1, 0, 0.0, 14511.0, 14511, 14511, 14511.0, 14511.0, 14511.0, 14511.0, 0.06891323823306458, 0.07671981600165392, 0.02436190648473572], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 21819758, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
