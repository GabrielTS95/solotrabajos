/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.99999748821168, "KoPercent": 2.5117883249667338E-6};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9999982668660558, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-2 | 61"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-4 | 65"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-2 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-3 | 79"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-2 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-4 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-4 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-7 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-3 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-4 | 79"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-5 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-1 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-5 | 65"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-2 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-8 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-5 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-3 | 61"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-6 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-3 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-3 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-1 | 61"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-3 | 30"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-9 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-7 | 61"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-6 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-4 | 61"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-3 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-6 | 65"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-10 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-1 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-3 | 65"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-2 | 30"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-1 | 65"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-7 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-5 | 61"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-1 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-6 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-7 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-1 | 79"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-4 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-1 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-2 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-6 | 61"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-7 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-5 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-8 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-8 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-8 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-2 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-2 | 79"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-6 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-9 | 67"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-4 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-9 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-2 | 65"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-1 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-1 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-4 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-7 | 59"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-1 | 33"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-5 | 2"], "isController": false}, {"data": [1.0, 500, 1500, "INIT - Cargar CSV + Selección random sin repetir"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-2 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-3 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-6 | 97"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-1 | 30"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-8 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-4 | 30"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-5 | 62"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-3 | 67"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 39812272, 1, 2.5117883249667338E-6, 0.26929837111534677, 0, 116835, 0.0, 1.0, 1.0, 1.0, 22117.99032775091, 4571.122563556601, 0.013920394570540475], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["POST Dispatcher | VU-9 | Q-2 | 61", 1, 0, 0.0, 31407.0, 31407, 31407, 31407.0, 31407.0, 31407.0, 31407.0, 0.03184003566083994, 0.0168217375903461, 0.011629075524564587], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-4 | 65", 1, 0, 0.0, 33987.0, 33987, 33987, 33987.0, 33987.0, 33987.0, 33987.0, 0.029423014682084327, 0.017843449333568715, 0.010286561773619324], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-2 | 2", 1, 0, 0.0, 25965.0, 25965, 25965, 25965.0, 25965.0, 25965.0, 25965.0, 0.03851338340073175, 0.016511108704024648, 0.014705793857115347], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-3 | 79", 1, 0, 0.0, 39070.0, 39070, 39070, 39070.0, 39070.0, 39070.0, 39070.0, 0.025595085743537242, 0.0254451145380087, 0.009348205144612234], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-2 | 67", 1, 0, 0.0, 32031.0, 32031, 32031, 32031.0, 32031.0, 32031.0, 32031.0, 0.031219755861509168, 0.03478685687302925, 0.010975695420061816], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-4 | 62", 1, 0, 0.0, 75161.0, 75161, 75161, 75161.0, 75161.0, 75161.0, 75161.0, 0.013304772421867724, 0.006925237989116696, 0.004807388472745174], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-4 | 97", 1, 0, 0.0, 23971.0, 23971, 23971, 23971.0, 23971.0, 23971.0, 23971.0, 0.041717074798715115, 0.02493247048516958, 0.015114291748362605], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-7 | 67", 1, 0, 0.0, 39984.0, 39984, 39984, 39984.0, 39984.0, 39984.0, 39984.0, 0.025010004001600642, 0.013897160426670668, 0.008792579531812724], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-3 | 2", 1, 0, 0.0, 34735.0, 34735, 34735, 34735.0, 34735.0, 34735.0, 34735.0, 0.02878940549877645, 0.0125672502519073, 0.01099282963869296], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-4 | 79", 1, 0, 0.0, 43454.0, 43454, 43454, 43454.0, 43454.0, 43454.0, 43454.0, 0.023012841165370276, 0.025687185011736547, 0.008405080660008285], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-5 | 97", 1, 0, 0.0, 26998.0, 26998, 26998, 26998.0, 26998.0, 26998.0, 26998.0, 0.03703978072449811, 0.02325837793540262, 0.013419686180457812], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-1 | 67", 1, 0, 0.0, 32572.0, 32572, 32572, 32572.0, 32572.0, 32572.0, 32572.0, 0.030701215768144417, 0.014960846355765688, 0.01079339616848827], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-5 | 65", 1, 0, 0.0, 32134.0, 32134, 32134, 32134.0, 32134.0, 32134.0, 32134.0, 0.03111968631356196, 0.014526572322150993, 0.01087973408228045], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-2 | 1", 1, 0, 0.0, 23896.0, 23896, 23896, 23896.0, 23896.0, 23896.0, 23896.0, 0.041848008034817544, 0.01385397922246401, 0.01299576812018748], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-8 | 67", 1, 0, 0.0, 31311.0, 31311, 31311, 31311.0, 31311.0, 31311.0, 31311.0, 0.03193765769218485, 0.017029258886653253, 0.011228082782408739], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-5 | 59", 1, 0, 0.0, 28932.0, 28932, 28932, 28932.0, 28932.0, 28932.0, 28932.0, 0.03456380478363058, 0.03712908716991566, 0.012590135922162312], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-3 | 61", 1, 0, 0.0, 34992.0, 34992, 34992, 34992.0, 34992.0, 34992.0, 34992.0, 0.02857796067672611, 0.01384244970278921, 0.010437653606538639], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-6 | 62", 1, 0, 0.0, 38010.0, 38010, 38010, 38010.0, 38010.0, 38010.0, 38010.0, 0.026308866087871613, 0.02458748520126283, 0.009506133254406735], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-3 | 62", 1, 0, 0.0, 33226.0, 33226, 33226, 33226.0, 33226.0, 33226.0, 33226.0, 0.03009691205682297, 0.01513663057545296, 0.010874860801781738], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-3 | 59", 1, 0, 0.0, 34807.0, 34807, 34807, 34807.0, 34807.0, 34807.0, 34807.0, 0.028729853190450197, 0.032208858850231274, 0.010465073476599534], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-1 | 61", 1, 0, 0.0, 32430.0, 32430, 32430, 32430.0, 32430.0, 32430.0, 32430.0, 0.030835646006783846, 0.027131754933703362, 0.011262237897008942], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-3 | 30", 1, 0, 0.0, 33557.0, 33557, 33557, 33557.0, 33557.0, 33557.0, 33557.0, 0.029800041720058408, 0.016151389799445717, 0.010796694802872724], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-9 | 59", 1, 0, 0.0, 33546.0, 33546, 33546, 33546.0, 33546.0, 33546.0, 33546.0, 0.029809813390568176, 0.036854710695761045, 0.010858457416681571], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-7 | 61", 1, 0, 0.0, 25058.0, 25058, 25058, 25058.0, 25058.0, 25058.0, 25058.0, 0.039907414797669405, 0.01933015404262112, 0.014575559701492538], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-6 | 59", 1, 0, 0.0, 24022.0, 24022, 24022, 24022.0, 24022.0, 24022.0, 24022.0, 0.041628507201731745, 0.03500209443426859, 0.015163508970943302], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-4 | 61", 1, 0, 0.0, 28288.0, 28288, 28288, 28288.0, 28288.0, 28288.0, 28288.0, 0.03535067873303168, 0.03193298616020927, 0.012911283052884616], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-3 | 1", 1, 0, 0.0, 19036.0, 19036, 19036, 19036.0, 19036.0, 19036.0, 19036.0, 0.05253204454717378, 0.01605715814772011, 0.016313662271485604], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-6 | 65", 1, 0, 0.0, 28355.0, 28355, 28355, 28355.0, 28355.0, 28355.0, 28355.0, 0.03526714865103157, 0.02025105801445953, 0.012329725797919237], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-10 | 67", 1, 0, 0.0, 33374.0, 33374, 33374, 33374.0, 33374.0, 33374.0, 33374.0, 0.029963444597590937, 0.030256056361239285, 0.010534023491340564], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-1 | 2", 1, 0, 0.0, 31457.0, 31457, 31457, 31457.0, 31457.0, 31457.0, 31457.0, 0.03178942683663413, 0.014528761483930444, 0.012138345598753854], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-3 | 65", 1, 0, 0.0, 27681.0, 27681, 27681, 27681.0, 27681.0, 27681.0, 27681.0, 0.036125862504967306, 0.018274606228098695, 0.012629940211697555], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-2 | 30", 1, 0, 0.0, 33429.0, 33429, 33429, 33429.0, 33429.0, 33429.0, 33429.0, 0.029914146399832482, 0.01650536398037632, 0.010838035463220557], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-1 | 65", 1, 0, 0.0, 50023.0, 50023, 50023, 50023.0, 50023.0, 50023.0, 50023.0, 0.019990804230054175, 0.021259751764188473, 0.006988972572616596], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-7 | 97", 1, 0, 0.0, 26044.0, 26044, 26044, 26044.0, 26044.0, 26044.0, 26044.0, 0.03839655966825373, 0.03224711065888496, 0.01391125355168177], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-5 | 61", 1, 0, 0.0, 30278.0, 30278, 30278, 30278.0, 30278.0, 30278.0, 30278.0, 0.03302728053372085, 0.01625561463769073, 0.012062698163683203], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-1 | 97", 1, 0, 0.0, 37085.0, 37085, 37085, 37085.0, 37085.0, 37085.0, 37085.0, 0.026965080221113658, 0.025174430362680328, 0.009769574962923015], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-6 | 2", 1, 0, 0.0, 28833.0, 28833, 28833, 28833.0, 28833.0, 28833.0, 28833.0, 0.03468248187840322, 0.01767993705129539, 0.013243017982866855], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-7 | 2", 1, 0, 0.0, 28946.0, 28946, 28946, 28946.0, 28946.0, 28946.0, 28946.0, 0.03454708768050853, 0.03326506684861466, 0.013191319612381675], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-1 | 79", 1, 0, 0.0, 30420.0, 30420, 30420, 30420.0, 30420.0, 30420.0, 30420.0, 0.03287310979618672, 0.03078643778763971, 0.012006389710716632], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-4 | 67", 1, 0, 0.0, 30608.0, 30608, 30608, 30608.0, 30608.0, 30608.0, 30608.0, 0.03267119707266074, 0.0159846384115264, 0.011485967720857292], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-1 | 62", 1, 0, 0.0, 29847.0, 29847, 29847, 29847.0, 29847.0, 29847.0, 29847.0, 0.0335042047776996, 0.017537357188327135, 0.012106011491942239], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-2 | 97", 1, 0, 0.0, 52557.0, 52557, 52557, 52557.0, 52557.0, 52557.0, 52557.0, 0.019026961204026107, 0.0176333849439656, 0.006893557233099302], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-6 | 61", 1, 0, 0.0, 24755.0, 24755, 24755, 24755.0, 24755.0, 24755.0, 24755.0, 0.040395879620278734, 0.019448406887497476, 0.01475396384568774], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-7 | 62", 1, 0, 0.0, 35625.0, 35625, 35625, 35625.0, 35625.0, 35625.0, 35625.0, 0.028070175438596492, 0.02757675438596491, 0.010142543859649123], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-5 | 67", 1, 0, 0.0, 29643.0, 29643, 29643, 29643.0, 29643.0, 29643.0, 29643.0, 0.03373477718179672, 0.032713509513207166, 0.011859882602975408], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-8 | 59", 1, 0, 0.0, 58393.0, 58393, 58393, 58393.0, 58393.0, 58393.0, 58393.0, 0.017125340366139778, 0.021674258900895655, 0.006238039020088024], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-8 | 2", 1, 0, 0.0, 26304.0, 26304, 26304, 26304.0, 26304.0, 26304.0, 26304.0, 0.03801703163017032, 0.017931861598996353, 0.014516268913473237], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-8 | 97", 1, 0, 0.0, 33420.0, 33420, 33420, 33420.0, 33420.0, 33420.0, 33420.0, 0.029922202274087373, 0.02594815978456014, 0.010840954144225014], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-2 | 59", 1, 0, 0.0, 26144.0, 26144, 26144, 26144.0, 26144.0, 26144.0, 26144.0, 0.03824969400244798, 0.04269472680156059, 0.013932749866126071], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-2 | 79", 1, 0, 0.0, 27503.0, 27503, 27503, 27503.0, 27503.0, 27503.0, 27503.0, 0.036359669854197724, 0.03355457813693052, 0.013279801294404247], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-6 | 67", 1, 0, 0.0, 36366.0, 36366, 36366, 36366.0, 36366.0, 36366.0, 36366.0, 0.02749821261617995, 0.02521564613925095, 0.009667340372875763], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-9 | 67", 1, 0, 0.0, 29934.0, 29934, 29934, 29934.0, 29934.0, 29934.0, 29934.0, 0.03340682835571591, 0.01706227659183537, 0.011744588093806374], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-4 | 2", 1, 0, 0.0, 43846.0, 43846, 43846, 43846.0, 43846.0, 43846.0, 43846.0, 0.0228070975687634, 0.010445828866943393, 0.008708569481822744], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-9 | 97", 1, 0, 0.0, 27036.0, 27036, 27036, 27036.0, 27036.0, 27036.0, 27036.0, 0.03698772007693446, 0.029546831077082406, 0.013400824363811214], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-2 | 65", 1, 0, 0.0, 33642.0, 33642, 33642, 33642.0, 33642.0, 33642.0, 33642.0, 0.02972474882587242, 0.017968378440639674, 0.01039205085904524], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-1 | 1", 1, 0, 0.0, 24767.0, 24767, 24767, 24767.0, 24767.0, 24767.0, 24767.0, 0.04037630718294505, 0.013366765756853879, 0.012538736019703638], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-1 | 59", 1, 0, 0.0, 49041.0, 49041, 49041, 49041.0, 49041.0, 49041.0, 49041.0, 0.020391101323382475, 0.01969413985236843, 0.007427617962521157], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-4 | 59", 1, 0, 0.0, 27779.0, 27779, 27779, 27779.0, 27779.0, 27779.0, 27779.0, 0.03599841606969293, 0.033502432142985705, 0.013112704291011195], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-7 | 59", 1, 0, 0.0, 25202.0, 25202, 25202, 25202.0, 25202.0, 25202.0, 25202.0, 0.03967939052456155, 0.04246934767081977, 0.014453527993810014], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-1 | 33", 1, 1, 100.0, 25826.0, 25826, 25826, 25826.0, 25826.0, 25826.0, 25826.0, 0.03872066909316193, 0.007297938608379153, 0.021704750058081004], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-5 | 2", 1, 0, 0.0, 44924.0, 44924, 44924, 44924.0, 44924.0, 44924.0, 44924.0, 0.02225981657911139, 0.009956050774641617, 0.00849959793206304], "isController": false}, {"data": ["INIT - Cargar CSV + Selección random sin repetir", 39812203, 0, 0.0, 0.20975023662973385, 0, 101, 0.0, 1.0, 1.0, 1.0, 22117.951994311094, 4571.095035810864, 0.0], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-2 | 62", 1, 0, 0.0, 32405.0, 32405, 32405, 32405.0, 32405.0, 32405.0, 32405.0, 0.030859435272334517, 0.015761215476006788, 0.011150381885511495], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-3 | 97", 1, 0, 0.0, 32261.0, 32261, 32261, 32261.0, 32261.0, 32261.0, 32261.0, 0.03099717925668764, 0.027152802532469544, 0.011230423343975697], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-6 | 97", 1, 0, 0.0, 116835.0, 116835, 116835, 116835.0, 116835.0, 116835.0, 116835.0, 0.008559079043094962, 0.005942876171523944, 0.00310099445799632], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-1 | 30", 1, 0, 0.0, 33789.0, 33789, 33789, 33789.0, 33789.0, 33789.0, 33789.0, 0.029595430465536122, 0.029508725102844118, 0.010722563186244044], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-8 | 62", 1, 0, 0.0, 35041.0, 35041, 35041, 35041.0, 35041.0, 35041.0, 35041.0, 0.028537998344796096, 0.014965727647612798, 0.010311581433178278], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-4 | 30", 1, 0, 0.0, 33748.0, 33748, 33748, 33748.0, 33748.0, 33748.0, 33748.0, 0.029631385563588956, 0.018374931477420885, 0.010735589886808108], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-5 | 62", 1, 0, 0.0, 29140.0, 29140, 29140, 29140.0, 29140.0, 29140.0, 29140.0, 0.03431708991077557, 0.021180078929306793, 0.012399729752916953], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-3 | 67", 1, 0, 0.0, 35875.0, 35875, 35875, 35875.0, 35875.0, 35875.0, 35875.0, 0.027874564459930314, 0.0273029181184669, 0.00979965156794425], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500/Internal Server Error", 1, 100.0, 2.5117883249667338E-6], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 39812272, 1, "500/Internal Server Error", 1, "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-1 | 33", 1, 1, "500/Internal Server Error", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
