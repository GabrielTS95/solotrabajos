/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9999978588333274, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-3 | 125"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-3 | 124"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-5 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-2 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-5 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-9 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-2 | 13"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-3 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-3 | 85"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-2 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-3 | 13"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-7 | 85"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-10 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-2 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-1 | 85"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-1 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-8 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-4 | 85"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-4 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-4 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-7 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-5 | 13"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-1 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-1 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-3 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-7 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-2 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-8 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-8 | Q-1 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-6 | 85"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-2 | 124"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-2 | 125"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-6 | 13"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-1 | 13"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-6 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-7 | Q-4 | 13"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-4 | 2"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-1 | Q-1 | 1"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-4 | 124"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-6 | Q-3 | 86"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-9 | Q-1 | 158"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-5 | 85"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-5 | Q-2 | 85"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-2 | Q-5 | 2"], "isController": false}, {"data": [1.0, 500, 1500, "INIT - Cargar CSV + Selección random sin repetir"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-3 | Q-1 | 124"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-3 | 152"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-4 | Q-1 | 125"], "isController": false}, {"data": [0.0, 500, 1500, "POST Dispatcher | VU-10 | Q-6 | 152"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 22417685, 0, 0.0, 0.4727016192796538, 0, 21798, 0.0, 1.0, 1.0, 1.0, 12454.297120660269, 2574.2522863158442, 0.009888259821132936], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["POST Dispatcher | VU-4 | Q-3 | 125", 1, 0, 0.0, 11996.0, 11996, 11996, 11996.0, 11996.0, 11996.0, 11996.0, 0.08336112037345782, 0.05120521944814938, 0.030283532010670224], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-3 | 124", 1, 0, 0.0, 12984.0, 12984, 12984, 12984.0, 12984.0, 12984.0, 12984.0, 0.07701786814540974, 0.043698614641096735, 0.029107338840110904], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-5 | 86", 1, 0, 0.0, 17190.0, 17190, 17190, 17190.0, 17190.0, 17190.0, 17190.0, 0.058173356602675974, 0.03300656268179174, 0.021530959133216985], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-2 | 2", 1, 0, 0.0, 16417.0, 16417, 16417, 16417.0, 16417.0, 16417.0, 16417.0, 0.06091246878235975, 0.03122953721751842, 0.023258569622951815], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-5 | 152", 1, 0, 0.0, 13962.0, 13962, 13962, 13962.0, 13962.0, 13962.0, 13962.0, 0.07162297665090961, 0.028956945638160723, 0.027278282122905027], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-9 | 152", 1, 0, 0.0, 10550.0, 10550, 10550, 10550.0, 10550.0, 10550.0, 10550.0, 0.0947867298578199, 0.038877369668246446, 0.036100414691943125], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-2 | 13", 1, 0, 0.0, 15079.0, 15079, 15079, 15079.0, 15079.0, 15079.0, 15079.0, 0.06631739505272233, 0.035554931527289606, 0.024609970820346175], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-3 | 2", 1, 0, 0.0, 13177.0, 13177, 13177, 13177.0, 13177.0, 13177.0, 13177.0, 0.07588980799878577, 0.040242349358731125, 0.02897745598391136], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-3 | 85", 1, 0, 0.0, 13732.0, 13732, 13732, 13732.0, 13732.0, 13732.0, 13732.0, 0.07282260413632391, 0.05120339353335276, 0.025672812591028257], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-2 | 152", 1, 0, 0.0, 19059.0, 19059, 19059, 19059.0, 19059.0, 19059.0, 19059.0, 0.05246864998163597, 0.02638804173881106, 0.019983177239099637], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-3 | 13", 1, 0, 0.0, 14694.0, 14694, 14694, 14694.0, 14694.0, 14694.0, 14694.0, 0.06805498843065197, 0.05250336021505376, 0.02525478086293725], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-7 | 85", 1, 0, 0.0, 12628.0, 12628, 12628, 12628.0, 12628.0, 12628.0, 12628.0, 0.07918910357934748, 0.06349048245961356, 0.027917252336078554], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-10 | 152", 1, 0, 0.0, 9452.0, 9452, 9452, 9452.0, 9452.0, 9452.0, 9452.0, 0.10579771476936098, 0.039880779200169275, 0.04029405152348709], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-2 | 2", 1, 0, 0.0, 11546.0, 11546, 11546, 11546.0, 11546.0, 11546.0, 11546.0, 0.08661008141347654, 0.041698017711761654, 0.03307084163346614], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-1 | 85", 1, 0, 0.0, 14304.0, 14304, 14304, 14304.0, 14304.0, 14304.0, 14304.0, 0.06991051454138703, 0.039392936416387025, 0.024646187255313198], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-1 | 152", 1, 0, 0.0, 16354.0, 16354, 16354, 16354.0, 16354.0, 16354.0, 16354.0, 0.06114711997064939, 0.025199301394154338, 0.023288453895071542], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-8 | 152", 1, 0, 0.0, 9748.0, 9748, 9748, 9748.0, 9748.0, 9748.0, 9748.0, 0.10258514567090685, 0.04738552138900288, 0.03907051446450554], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-4 | 85", 1, 0, 0.0, 17062.0, 17062, 17062, 17062.0, 17062.0, 17062.0, 17062.0, 0.05860977611065526, 0.038577137791583636, 0.020662235523385298], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-4 | 152", 1, 0, 0.0, 9835.0, 9835, 9835, 9835.0, 9835.0, 9835.0, 9835.0, 0.10167768174885612, 0.053221911540416875, 0.03872489832231825], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-4 | 86", 1, 0, 0.0, 17976.0, 17976, 17976, 17976.0, 17976.0, 17976.0, 17976.0, 0.055629728526924785, 0.05128365598575879, 0.020589518663773922], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-7 | 86", 1, 0, 0.0, 15532.0, 15532, 15532, 15532.0, 15532.0, 15532.0, 15532.0, 0.06438320885912954, 0.06073650366984291, 0.02382933218516611], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-5 | 13", 1, 0, 0.0, 13226.0, 13226, 13226, 13226.0, 13226.0, 13226.0, 13226.0, 0.07560864962951762, 0.04659087687131407, 0.0280578973234538], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-1 | 86", 1, 0, 0.0, 16086.0, 16086, 16086, 16086.0, 16086.0, 16086.0, 16086.0, 0.062165858510506024, 0.055670011966927765, 0.023008652710431433], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-1 | 2", 1, 0, 0.0, 12165.0, 12165, 12165, 12165.0, 12165.0, 12165.0, 12165.0, 0.08220304151253596, 0.038693228524455406, 0.03138807542129059], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-3 | 2", 1, 0, 0.0, 11502.0, 11502, 11502, 11502.0, 11502.0, 11502.0, 11502.0, 0.0869414014953921, 0.039395322552599546, 0.033197351547556944], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-7 | 152", 1, 0, 0.0, 21025.0, 21025, 21025, 21025.0, 21025.0, 21025.0, 21025.0, 0.04756242568370987, 0.02364186979785969, 0.01811459571938169], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-2 | 86", 1, 0, 0.0, 14996.0, 14996, 14996, 14996.0, 14996.0, 14996.0, 14996.0, 0.06668444918644971, 0.050794795278741, 0.024681060782875432], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-8 | 86", 1, 0, 0.0, 17207.0, 17207, 17207, 17207.0, 17207.0, 17207.0, 17207.0, 0.05811588307084326, 0.06884234977044226, 0.02150968719125937], "isController": false}, {"data": ["POST Dispatcher | VU-8 | Q-1 | 2", 1, 0, 0.0, 12168.0, 12168, 12168, 12168.0, 12168.0, 12168.0, 12168.0, 0.0821827744904668, 0.039165228468113086, 0.03138033674391848], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-6 | 85", 1, 0, 0.0, 13090.0, 13090, 13090, 13090.0, 13090.0, 13090.0, 13090.0, 0.07639419404125286, 0.05819088999236058, 0.026931937547746372], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-2 | 124", 1, 0, 0.0, 10773.0, 10773, 10773, 10773.0, 10773.0, 10773.0, 10773.0, 0.092824654228163, 0.04740946695442309, 0.0350811925647452], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-2 | 125", 1, 0, 0.0, 14183.0, 14183, 14183, 14183.0, 14183.0, 14183.0, 14183.0, 0.070506944934076, 0.061555867940492136, 0.0256138510893323], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-6 | 13", 1, 0, 0.0, 7157.0, 7157, 7157, 7157.0, 7157.0, 7157.0, 7157.0, 0.1397233477714126, 0.08309718632108425, 0.05185046108704765], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-1 | 13", 1, 0, 0.0, 13983.0, 13983, 13983, 13983.0, 13983.0, 13983.0, 13983.0, 0.0715154115711936, 0.04246227562039619, 0.026538922262747622], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-6 | 86", 1, 0, 0.0, 14415.0, 14415, 14415, 14415.0, 14415.0, 14415.0, 14415.0, 0.0693721817551162, 0.07546934616718697, 0.025675836801942423], "isController": false}, {"data": ["POST Dispatcher | VU-7 | Q-4 | 13", 1, 0, 0.0, 12277.0, 12277, 12277, 12277.0, 12277.0, 12277.0, 12277.0, 0.08145312372729493, 0.054249053107436676, 0.03022674513317586], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-4 | 2", 1, 0, 0.0, 11595.0, 11595, 11595, 11595.0, 11595.0, 11595.0, 11595.0, 0.086244070720138, 0.04110068995256576, 0.03293108559724019], "isController": false}, {"data": ["POST Dispatcher | VU-1 | Q-1 | 1", 1, 0, 0.0, 7758.0, 7758, 7758, 7758.0, 7758.0, 7758.0, 7758.0, 0.1288992008249549, 0.0390222189997422, 0.04002924400618716], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-4 | 124", 1, 0, 0.0, 11382.0, 11382, 11382, 11382.0, 11382.0, 11382.0, 11382.0, 0.08785802143735723, 0.04856214856791425, 0.03320415458618872], "isController": false}, {"data": ["POST Dispatcher | VU-6 | Q-3 | 86", 1, 0, 0.0, 15073.0, 15073, 15073, 15073.0, 15073.0, 15073.0, 15073.0, 0.06634379353811451, 0.08811285079280833, 0.024554978272407615], "isController": false}, {"data": ["POST Dispatcher | VU-9 | Q-1 | 158", 1, 0, 0.0, 21798.0, 21798, 21798, 21798.0, 21798.0, 21798.0, 21798.0, 0.04587576841912102, 0.030509178020919354, 0.0168898092714928], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-5 | 85", 1, 0, 0.0, 11064.0, 11064, 11064, 11064.0, 11064.0, 11064.0, 11064.0, 0.09038322487346348, 0.05251759648409255, 0.031863617362617495], "isController": false}, {"data": ["POST Dispatcher | VU-5 | Q-2 | 85", 1, 0, 0.0, 12493.0, 12493, 12493, 12493.0, 12493.0, 12493.0, 12493.0, 0.08004482510205715, 0.05549982990474666, 0.028218927599455695], "isController": false}, {"data": ["POST Dispatcher | VU-2 | Q-5 | 2", 1, 0, 0.0, 15400.0, 15400, 15400, 15400.0, 15400.0, 15400.0, 15400.0, 0.06493506493506493, 0.03024807224025974, 0.024794541396103896], "isController": false}, {"data": ["INIT - Cargar CSV + Selección random sin repetir", 22417637, 0, 0.0, 0.4434487898969904, 0, 186, 0.0, 1.0, 1.0, 1.0, 12454.270453934341, 2574.2351112559763, 0.0], "isController": false}, {"data": ["POST Dispatcher | VU-3 | Q-1 | 124", 1, 0, 0.0, 11546.0, 11546, 11546, 11546.0, 11546.0, 11546.0, 11546.0, 0.08661008141347654, 0.057852827819158154, 0.03273252100294474], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-3 | 152", 1, 0, 0.0, 15779.0, 15779, 15779, 15779.0, 15779.0, 15779.0, 15779.0, 0.06337537233031244, 0.02642703514164396, 0.02413710469611509], "isController": false}, {"data": ["POST Dispatcher | VU-4 | Q-1 | 125", 1, 0, 0.0, 8707.0, 8707, 8707, 8707.0, 8707.0, 8707.0, 8707.0, 0.11485012059262663, 0.07839866630297461, 0.041722895371540135], "isController": false}, {"data": ["POST Dispatcher | VU-10 | Q-6 | 152", 1, 0, 0.0, 15677.0, 15677, 15677, 15677.0, 15677.0, 15677.0, 15677.0, 0.06378771448618996, 0.08764581472858328, 0.024294149071888756], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 22417685, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
