/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.9613136537572, "KoPercent": 0.038686346242798875};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.8606680060948477, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9729574223245109, 500, 1500, "ver_agente_catalog"], "isController": false}, {"data": [3.027550711474417E-4, 500, 1500, "Transaction Controller - Quality"], "isController": true}, {"data": [0.9714165776217372, 500, 1500, "/api/v1/explicability/quality-trend"], "isController": false}, {"data": [0.9710610932475884, 500, 1500, "editar_agente_catalog"], "isController": false}, {"data": [0.9725886389630194, 500, 1500, "/api/v1/explicability/quality-matrix"], "isController": false}, {"data": [0.9662379421221865, 500, 1500, "crear_agente_catalog"], "isController": false}, {"data": [0.9769207293812466, 500, 1500, "/api/v1/explicability/experience-agents"], "isController": false}, {"data": [0.9730077120822622, 500, 1500, "/models/deployments"], "isController": false}, {"data": [0.9772459064758814, 500, 1500, "listar_agentes_registry"], "isController": false}, {"data": [0.002519083969465649, 500, 1500, "Transaction Controller - Filtro Onwer"], "isController": true}, {"data": [0.887987012987013, 500, 1500, "Transaction Controller - Models Admin"], "isController": true}, {"data": [0.21075031525851198, 500, 1500, "Transaction Controller - Agent Center Reader"], "isController": true}, {"data": [0.9469453376205788, 500, 1500, "agente_registrar_registry"], "isController": false}, {"data": [0.9766554775709491, 500, 1500, "/api/v1/explicability/experience-nps"], "isController": false}, {"data": [0.9692543021032505, 500, 1500, "/api/v1/explicability/risk-watchlist"], "isController": false}, {"data": [0.42567780580075665, 500, 1500, "Transaction Controller - Catalog Reader"], "isController": true}, {"data": [0.8964631495751828, 500, 1500, "listar_agentes_catalog"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller - Catalog Admin"], "isController": true}, {"data": [0.9748245346353372, 500, 1500, "/api/v1/explicability/filters"], "isController": false}, {"data": [0.952922077922078, 500, 1500, "eliminar_agente_registry"], "isController": false}, {"data": [0.001607717041800643, 500, 1500, "Transaction Controller - Registry Admin"], "isController": true}, {"data": [1.0, 500, 1500, "Init rol flags"], "isController": false}, {"data": [0.9788737775061125, 500, 1500, "/api/v1/explicability/usage-top"], "isController": false}, {"data": [0.9724111282843895, 500, 1500, "/api/v1/explicability/metadata/overview"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller - Agent Center Admin"], "isController": true}, {"data": [0.8945491998098558, 500, 1500, "Transaction Controller - Models Reader"], "isController": true}, {"data": [0.973892975623828, 500, 1500, "traer_agente_registry"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller - Agents Explicability Admin"], "isController": true}, {"data": [0.9448051948051948, 500, 1500, "registrar_registry"], "isController": false}, {"data": [3.1720856463124506E-4, 500, 1500, "Transaction Controller - Agents Explicability Reader"], "isController": true}, {"data": [0.9763968425940257, 500, 1500, "/api/v1/explicability/metadata/overview/filtros"], "isController": false}, {"data": [0.9657803293548874, 500, 1500, "/models/catalog"], "isController": false}, {"data": [0.9749158764148057, 500, 1500, "/api/v1/explicability/cost-agents"], "isController": false}, {"data": [0.9752869166029074, 500, 1500, "/api/v1/explicability/cost-daily"], "isController": false}, {"data": [0.8477541371158392, 500, 1500, "login_reader"], "isController": false}, {"data": [0.9678456591639871, 500, 1500, "eliminar_agente_catalog"], "isController": false}, {"data": [0.9739515697807654, 500, 1500, "/api/v1/explicability/usage-identities"], "isController": false}, {"data": [0.9790862787467202, 500, 1500, "/api/v1/explicability/metadata/filters"], "isController": false}, {"data": [0.9701441317776253, 500, 1500, "api/v1/explicability/summary-cards"], "isController": false}, {"data": [0.7899691358024692, 500, 1500, "Transaction Controller - MetaData"], "isController": true}, {"data": [0.9764296754250387, 500, 1500, "Transaction Controller - Filtros"], "isController": true}, {"data": [0.8509615384615384, 500, 1500, "login_admin"], "isController": false}, {"data": [0.7594466403162056, 500, 1500, "Transaction Controller - Registry Reader"], "isController": true}, {"data": [0.9448051948051948, 500, 1500, "editar_agente_registry"], "isController": false}, {"data": [0.9793483249196879, 500, 1500, "/api/v1/explicability/value-funnel"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 237810, 92, 0.038686346242798875, -5.278658582600403E7, -1793320194271, 65710, 162.0, 575.0, 1111.0, 22591.800000000032, 66.0497652110129, 274.81885590943824, 127.60527103367771], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["ver_agente_catalog", 6952, 19, 0.27330264672036825, 207.4027617951664, 128, 5714, 145.0, 272.0, 418.34999999999945, 1445.3500000000013, 1.9340949898816118, 3.4084695027585616, 3.816307093116714], "isController": false}, {"data": ["Transaction Controller - Quality", 6606, 1, 0.015137753557372086, 4964.840902210112, 0, 55287, 3787.5, 6808.0, 8635.599999999999, 27204.47000000014, 1.8423741023446345, 36.698906415898385, 78.83325471135721], "isController": true}, {"data": ["/api/v1/explicability/quality-trend", 13102, 2, 0.015264845061822623, 222.66959242863788, 128, 7853, 143.0, 410.0, 480.0, 1560.0, 3.668164131726904, 4.75946803789685, 7.48666766382572], "isController": false}, {"data": ["editar_agente_catalog", 311, 1, 0.3215434083601286, 246.05466237942133, 145, 2724, 177.0, 319.6, 439.9999999999992, 2279.5599999999995, 0.0870716759477794, 0.04277930873558488, 0.29469479592750936], "isController": false}, {"data": ["/api/v1/explicability/quality-matrix", 13115, 2, 0.015249714067861228, 215.2632100648117, 128, 8431, 142.0, 287.0, 457.0, 1724.0400000000009, 3.6679076677309146, 3.307039462327106, 7.647323491469842], "isController": false}, {"data": ["crear_agente_catalog", 622, 1, 0.1607717041800643, 275.05305466237934, 144, 4510, 194.5, 382.0, 516.3500000000003, 1914.7299999999973, 0.17321693081320336, 0.08670174660521271, 0.5882845419832448], "isController": false}, {"data": ["/api/v1/explicability/experience-agents", 13107, 2, 0.015259021896696421, 202.77798123140266, 128, 29743, 141.0, 241.0, 387.0, 1416.92, 3.673848989586417, 3.025858286923205, 7.512666279892242], "isController": false}, {"data": ["/models/deployments", 6613, 1, 0.015121729925903523, 224.65038560411298, 135, 8331, 155.0, 279.0, 415.59999999999854, 1700.7199999999993, 1.844980358896527, 23.029794038252025, 3.65303284078291], "isController": false}, {"data": ["listar_agentes_registry", 13558, 2, 0.01475143826523086, 207.50095884348744, 130, 28055, 149.0, 262.0, 393.0, 1413.2299999999996, 3.7745041404567656, 42.758629725177094, 7.429163885598394], "isController": false}, {"data": ["Transaction Controller - Filtro Onwer", 6550, 1, 0.015267175572519083, 2606.031450381684, 0, 30394, 2043.0, 3817.7000000000016, 5184.249999999999, 11277.049999999968, 1.8387626895680116, 16.41513254627857, 41.46324632491344], "isController": true}, {"data": ["Transaction Controller - Models Admin", 308, 0, 0.0, 487.6818181818184, 296, 3829, 371.0, 672.0000000000005, 1038.1500000000003, 3031.6500000000005, 0.08684430085685438, 2.9565198755377367, 0.3440256002477882], "isController": true}, {"data": ["Transaction Controller - Agent Center Reader", 6344, 29, 0.457124842370744, -1.4133967252728558E9, -1793320194271, 29230, 1562.0, 2813.0, 4120.25, 6850.750000000008, 1.7624528097981709, 149.02096202421552, 24.04623768354485], "isController": true}, {"data": ["agente_registrar_registry", 311, 0, 0.0, 338.42765273311915, 148, 5006, 203.0, 458.0, 913.5999999999998, 3882.3999999999974, 0.08703804766102739, 0.04353186920154485, 0.2916913188468158], "isController": false}, {"data": ["/api/v1/explicability/experience-nps", 13108, 2, 0.015257857796765334, 201.49504119621682, 128, 6589, 141.0, 244.0, 396.0, 1502.5499999999993, 3.672224029198495, 2.6990580908553277, 7.498565231073044], "isController": false}, {"data": ["/api/v1/explicability/risk-watchlist", 13075, 2, 0.015296367112810707, 241.64596558317297, 128, 26747, 145.0, 429.0, 508.0, 1421.2399999999998, 3.6666235739077737, 4.598627812135528, 7.880997516949195], "isController": false}, {"data": ["Transaction Controller - Catalog Reader", 6344, 17, 0.26796973518284994, 1277.508196721314, 0, 14955, 1022.0, 1797.0, 2727.5, 5456.500000000002, 1.7624528097981709, 106.50917095247044, 13.716441106339886], "isController": true}, {"data": ["listar_agentes_catalog", 20244, 3, 0.014819205690574985, 355.36707172495727, 130, 14470, 213.0, 597.0, 794.9000000000015, 2108.9100000000144, 5.625671112217743, 110.10980269292115, 10.918926255101425], "isController": false}, {"data": ["Transaction Controller - Catalog Admin", 312, 2, 0.6410256410256411, 2700.4391025641035, 1621, 17899, 2218.5, 4269.599999999999, 6054.099999999999, 9321.570000000002, 0.08673588672293193, 5.461634078043394, 1.8988683755466516], "isController": true}, {"data": ["/api/v1/explicability/filters", 6554, 1, 0.015257857796765334, 204.32438205675865, 128, 5214, 142.0, 254.0, 409.5, 1470.8499999999976, 1.8398184547770715, 2.053138613891612, 3.732645797155945], "isController": false}, {"data": ["eliminar_agente_registry", 308, 3, 0.974025974025974, 260.34740259740266, 143, 3078, 176.0, 404.1, 579.6000000000004, 1726.0100000000052, 0.08685003114475955, 0.04847643403359461, 0.18088643753931868], "isController": false}, {"data": ["Transaction Controller - Registry Admin", 311, 3, 0.9646302250803859, 2621.916398713826, 1482, 30410, 2007.0, 4597.800000000002, 5666.399999999999, 9492.719999999998, 0.08687995369382275, 5.043130545580967, 2.08851099998687], "isController": true}, {"data": ["Init rol flags", 10406, 0, 0.0, 0.3771862387084369, 0, 37, 0.0, 1.0, 1.0, 3.0, 2.890882385869736, 0.0, 0.0], "isController": false}, {"data": ["/api/v1/explicability/usage-top", 13088, 2, 0.015281173594132029, 201.41534229828838, 128, 7476, 141.0, 266.0, 423.0, 1300.1100000000006, 3.654874613617368, 3.16082734394875, 7.445188716360032], "isController": false}, {"data": ["/api/v1/explicability/metadata/overview", 6470, 1, 0.015455950540958269, 217.00247295208683, 129, 5414, 146.0, 279.0, 452.4499999999998, 1616.6399999999994, 1.834150290898504, 4.105299634371211, 3.667408322694364], "isController": false}, {"data": ["Transaction Controller - Agent Center Admin", 308, 4, 1.2987012987012987, 5259.983766233767, 3157, 32394, 4394.5, 8276.600000000002, 9354.500000000002, 17683.970000000165, 0.08680076069030278, 10.50541714555628, 4.006060196433221], "isController": true}, {"data": ["Transaction Controller - Models Reader", 6311, 1, 0.01584534938995405, 498.38329900174233, 273, 26832, 368.0, 645.0, 977.3999999999996, 3216.640000000003, 1.7588372444307203, 59.847855705567966, 6.966911933126143], "isController": true}, {"data": ["traer_agente_registry", 6933, 29, 0.4182893408336939, 210.83066493581387, 135, 5649, 154.0, 276.60000000000036, 398.2999999999993, 1322.3199999999997, 1.9307589138513364, 2.9980351480345973, 3.7662430328336236], "isController": false}, {"data": ["Transaction Controller - Agents Explicability Admin", 299, 0, 0.0, 5497.040133779264, 3620, 19594, 4701.0, 7780.0, 9447.0, 17109.0, 0.08604742450561582, 2.1806213659172484, 4.235474366465045], "isController": true}, {"data": ["registrar_registry", 308, 3, 0.974025974025974, 291.103896103896, 146, 5439, 195.5, 427.0, 644.0500000000002, 2089.0300000000034, 0.08677503403384451, 0.04372730739534593, 0.30292793720812033], "isController": false}, {"data": ["Transaction Controller - Agents Explicability Reader", 6305, 1, 0.01586042823156225, -5.688507834204595E8, -1793320193241, 65710, 4347.0, 7772.200000000004, 9662.899999999998, 36140.03999999999, 1.7584269929280836, 44.045446903401, 85.62599168623805], "isController": true}, {"data": ["/api/v1/explicability/metadata/overview/filtros", 6461, 1, 0.015477480266212661, 204.17690759944205, 129, 5205, 143.0, 264.0, 423.0, 1378.9000000000005, 1.8332411652728908, 1.8946541502298717, 3.7676351993192236], "isController": false}, {"data": ["/models/catalog", 6619, 1, 0.015108022359873092, 272.3669738631204, 137, 26686, 188.0, 351.0, 534.0, 1869.4000000000024, 1.8452077287413615, 39.77648288159685, 3.65888917681057], "isController": false}, {"data": ["/api/v1/explicability/cost-agents", 6538, 1, 0.015295197308045273, 204.68828387886182, 128, 5625, 141.0, 243.0, 405.09999999999854, 1585.0999999999967, 1.8363249682898304, 1.5271210819052055, 3.7560432260484298], "isController": false}, {"data": ["/api/v1/explicability/cost-daily", 6535, 1, 0.015302218821729151, 202.383932670237, 128, 5349, 141.0, 246.40000000000055, 416.0, 1518.2000000000016, 1.837038003214184, 1.4900576445342708, 3.75570728537015], "isController": false}, {"data": ["login_reader", 6345, 1, 0.015760441292356184, 507.96438140267963, 128, 16480, 478.0, 553.0, 614.0, 885.54, 1.7625044062610158, 4.745910844811834, 0.8105554118051962], "isController": false}, {"data": ["eliminar_agente_catalog", 311, 1, 0.3215434083601286, 258.12540192926053, 144, 2976, 179.0, 350.40000000000003, 484.5999999999998, 1995.1999999999975, 0.0870284756612695, 0.04749586492313091, 0.18125858610418288], "isController": false}, {"data": ["/api/v1/explicability/usage-identities", 13091, 2, 0.015277671682835536, 220.4033305324264, 128, 26099, 143.0, 413.0, 470.39999999999964, 1302.1599999999999, 3.6580189582120726, 3.9136862779824755, 7.512346268057819], "isController": false}, {"data": ["/api/v1/explicability/metadata/filters", 6479, 1, 0.01543448062972681, 197.37629263775275, 128, 5185, 144.0, 249.0, 405.0, 1268.3999999999987, 1.835327577220296, 3.627325961323283, 3.6679698676016104], "isController": false}, {"data": ["api/v1/explicability/summary-cards", 13113, 2, 0.015252039960344696, 239.63547624494788, 127, 17838, 144.0, 427.0, 498.0, 1504.8800000000047, 3.659589265316454, 2.7749272693088476, 7.469100630402137], "isController": false}, {"data": ["Transaction Controller - MetaData", 6480, 1, 0.015432098765432098, 627.2538580246918, 0, 7066, 463.0, 856.9000000000005, 1342.0, 3675.7599999999984, 1.8342588603477958, 9.612638514142757, 11.084775877910824], "isController": true}, {"data": ["Transaction Controller - Filtros", 6470, 1, 0.015455950540958269, 203.8928902627504, 0, 5205, 143.0, 264.0, 423.0, 1378.4499999999998, 1.834221527467113, 1.8930304135616727, 3.7644063000371095], "isController": true}, {"data": ["login_admin", 312, 0, 0.0, 542.8621794871792, 420, 9777, 475.0, 576.0999999999999, 721.8499999999997, 1248.7500000000005, 0.0867805420223649, 0.23353072806510544, 0.040000406088433825], "isController": false}, {"data": ["Transaction Controller - Registry Reader", 6325, 23, 0.36363636363636365, 626.0683003952561, 0, 28364, 484.0, 830.4000000000005, 1257.0999999999995, 3159.319999999996, 1.760058770658081, 42.58157484345564, 10.346753100277436], "isController": true}, {"data": ["editar_agente_registry", 308, 3, 0.974025974025974, 372.8896103896104, 143, 28510, 172.5, 390.9000000000002, 840.0000000000002, 3278.2300000000114, 0.08682116700051472, 0.04264640571644094, 0.3019851118964167], "isController": false}, {"data": ["/api/v1/explicability/value-funnel", 13074, 2, 0.01529753709652746, 197.7292335933905, 128, 6901, 142.0, 244.0, 407.0, 1339.25, 3.658244831546975, 3.54440095987305, 7.462777911027899], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, 1.0869565217391304, 4.205037635086834E-4], "isController": false}, {"data": ["502/Bad Gateway", 4, 4.3478260869565215, 0.0016820150540347335], "isController": false}, {"data": ["401/Unauthorized", 33, 35.869565217391305, 0.013876624195786552], "isController": false}, {"data": ["404/Not Found", 54, 58.69565217391305, 0.022707203229468904], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 237810, 92, "404/Not Found", 54, "401/Unauthorized", 33, "502/Bad Gateway", 4, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["ver_agente_catalog", 6952, 19, "404/Not Found", 18, "401/Unauthorized", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["/api/v1/explicability/quality-trend", 13102, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["editar_agente_catalog", 311, 1, "404/Not Found", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/quality-matrix", 13115, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["crear_agente_catalog", 622, 1, "502/Bad Gateway", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/experience-agents", 13107, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/models/deployments", 6613, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["listar_agentes_registry", 13558, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["/api/v1/explicability/experience-nps", 13108, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/risk-watchlist", 13075, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["listar_agentes_catalog", 20244, 3, "401/Unauthorized", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["/api/v1/explicability/filters", 6554, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["eliminar_agente_registry", 308, 3, "404/Not Found", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["/api/v1/explicability/usage-top", 13088, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/metadata/overview", 6470, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["traer_agente_registry", 6933, 29, "404/Not Found", 28, "401/Unauthorized", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["registrar_registry", 308, 3, "502/Bad Gateway", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["/api/v1/explicability/metadata/overview/filtros", 6461, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/models/catalog", 6619, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/cost-agents", 6538, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/cost-daily", 6535, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["login_reader", 6345, 1, "Non HTTP response code: java.net.SocketException/Non HTTP response message: Connection reset", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["eliminar_agente_catalog", 311, 1, "404/Not Found", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/usage-identities", 13091, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/metadata/filters", 6479, 1, "401/Unauthorized", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["api/v1/explicability/summary-cards", 13113, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["editar_agente_registry", 308, 3, "404/Not Found", 3, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["/api/v1/explicability/value-funnel", 13074, 2, "401/Unauthorized", 2, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
